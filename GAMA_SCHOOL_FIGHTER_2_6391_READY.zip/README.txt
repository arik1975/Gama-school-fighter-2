GAMA SCHOOL FIGHTER 2 - OpenBOR 3.0 Build 6391
================================================

Target engine: OpenBOR v3.0 Build 6391
Player: YANTI - KILAT MERAH
Enemy: SCHOOL THUG
Stage: GAMA SCHOOL - MAKASSAR STREET

This is the mod/source package for packing with borpak.
It is NOT the OpenBOR engine itself.

Final target:
    GAMA_SCHOOL_FIGHTER_2.pak

Android installation:
    Put the finished .pak into the OpenBOR Paks folder.
